## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----detrend-dir-thresh, eval=FALSE--------------------------------------
#  brightness_folder("path/to/some/dir", def = "e", thresh = "Huang", detrend = TRUE)

